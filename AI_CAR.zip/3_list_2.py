listTest = [0,30,50,1]

listTest[1] = 100
listTest[2] = 10

print("0=",listTest[0])
print("1=",listTest[1])
print("2=",listTest[2])
print("3=",listTest[3])
