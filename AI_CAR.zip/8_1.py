import tensorflow as tf

print("tensorflow:",tf.__version__)