import matplotlib.pyplot as plt
from rplidar import RPLidar
import numpy as np

PORT_NAME = '/dev/ttyUSB0'
lidar = RPLidar(PORT_NAME)

# 시각화 설정
plt.ion()  # 실시간 업데이트
fig = plt.figure()
ax = fig.add_subplot(111, polar=True)
scan_data = [0]*360

try:
    print("Lidar scanning...")
    for scan in lidar.iter_measures(max_buf_meas=500):
        quality, angle, distance = scan[0], scan[1], scan[2]
        if quality > 0:  # 신뢰도 있는 데이터만 사용
            scan_data[int(angle)] = distance

        if int(angle) == 359:
            ax.clear()
            ax.set_theta_zero_location('N')  # 0도 위쪽
            ax.set_theta_direction(-1)       # 시계 방향
            angles = np.radians(np.arange(360))
            distances = np.array(scan_data)
            ax.plot(angles, distances)
            plt.pause(0.001)

except KeyboardInterrupt:
    print("stop")

finally:
    print("Lidar connect end")
    lidar.stop()
    lidar.disconnect()
