import sys
sys.path.insert(0, '/home/pi/rplidar_git')

import numpy as np
import matplotlib.pyplot as plt
from rplidar import RPLidar
import math

GRID_SIZE = 500  # 500x500 grid
RESOLUTION = 10  # mm per grid cell

map_grid = np.zeros((GRID_SIZE, GRID_SIZE))

lidar = RPLidar('/dev/ttyUSB0', baudrate=115200, timeout=2)
lidar.start_motor()

try:
    for i, scan in enumerate(lidar.iter_scans()):
        map_grid[:] = 0  # clear map

        for (_, angle, distance) in scan:
            if distance == 0:
                continue
            angle_rad = math.radians(angle)
            x = int(distance * math.cos(angle_rad) / RESOLUTION + GRID_SIZE // 2)
            y = int(distance * math.sin(angle_rad) / RESOLUTION + GRID_SIZE // 2)

            if 0 <= x < GRID_SIZE and 0 <= y < GRID_SIZE:
                map_grid[y, x] = 255  # obstacle point

        plt.clf()
        plt.imshow(map_grid, cmap='gray', origin='lower')
        plt.title(f'Scan {i}')
        plt.pause(0.01)

        if i > 300:
            break

finally:
    lidar.stop()
    lidar.stop_motor()
    lidar.disconnect()

    
