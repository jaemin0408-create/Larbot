import sys
sys.path.insert(0, '/home/pi/rplidar_git')

from rplidar import RPLidar
import matplotlib.pyplot as plt
import numpy as np


lidar = RPLidar('/dev/ttyUSB0', baudrate=115200, timeout=2)
plt.ion()
fig, ax = plt.subplots()

try:
    print("Starting scan...")
    for scan in lidar.iter_scans():
        ax.clear()
        ax.set_xlim(-1000, 1000)
        ax.set_ylim(-1000, 1000)
        ax.set_title('2D Lidar Mapping')

        angles = []
        distances = []
        print(scan)
    
        for (_, angle, distance) in scan:
            angles.append(np.radians(angle))
            distances.append(distance)

        # Convert polar to cartesian
        x = -np.array(distances) * np.cos(angles)
        y = np.array(distances) * np.sin(angles)

        ax.plot(x, y, 'k.', markersize=2)
        plt.pause(0.01)

except KeyboardInterrupt:
    print("Stopping scan...")

finally:
    lidar.stop()
    lidar.disconnect()
